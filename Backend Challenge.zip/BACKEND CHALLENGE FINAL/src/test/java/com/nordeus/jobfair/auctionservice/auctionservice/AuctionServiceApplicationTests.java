package com.nordeus.jobfair.auctionservice.auctionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
