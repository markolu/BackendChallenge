INSERT INTO users (username, password, tokens) VALUES ('Marko', 'marko123', 150);
INSERT INTO users (username, password, tokens) VALUES ('Mile', 'mile123', 300);

INSERT INTO positions (name) VALUES ('GK');
INSERT INTO positions (name) VALUES ('DL');
INSERT INTO positions (name) VALUES ('DC');
INSERT INTO positions (name) VALUES ('DR');
INSERT INTO positions (name) VALUES ('DMC');
INSERT INTO positions (name) VALUES ('ML');
INSERT INTO positions (name) VALUES ('MC');
INSERT INTO positions (name) VALUES ('MR');
INSERT INTO positions (name) VALUES ('AML');
INSERT INTO positions (name) VALUES ('AMC');
INSERT INTO positions (name) VALUES ('AMR');
INSERT INTO positions (name) VALUES ('ST');