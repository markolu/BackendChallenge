var stompClient = null;
var activeAuctionIds = [];
var joinedAuctions = [];
var winningAuctions = [];
var myId = null;
var tokens;
var username;

$(document).ready(function() {
    console.log("Index page is ready");
    connect();
});

//REQUESTS------------------------------------------------------------------


/*
    Function that retrieves information about user with specific id from the server
    Return value of type:
    {
        "username" : John Doe,
        "tokens" : 123
    }
*/
function getUserInfo(userId) {
    const url = "http://localhost:8082/users/" + userId;

    return fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            return response.json();
        })
        .then(userInfo => {
            console.log('User Info:', userInfo);
            return userInfo;
        })
        .catch(error => {
            console.error('Error fetching user info:', error);
            throw error;
        });
}

/*
    Function that retrieves all active auctions from the server
    Return value of type:
    [
        {
            "auctionId": 1,
            "player": {player},
            "timestamp": timestamp
        },
        {
            "auctionId": 2,
            "player": {player},
            "timestamp": timestamp
        }
    ]

*/
function getActiveAuctions(){
    const url = "http://localhost:8082/auctions/active";

    return fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            return response.json();
        })
        .then(activeAuctions => {
            console.log('Active auctions:', activeAuctions);
            return activeAuctions;
        })
        .catch(error => {
            console.error('Error fetching active auctions:', error);
            throw error;
        });
}

/*
    Function that joins the user to the active auction
     Return value of type:
    {
        "auctionId" : 1,
        "currentBid" : 123,
        "timestamp" : timestamp,
        "player" : {player}
        "currentWinnerId" : 5 (null)
    }

*/
function joinAuction(auctionId, userId){

    const jsonData = {
        auctionId : auctionId,
        userId : userId
    };

    const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(jsonData)
      };

    const url = "http://localhost:8082/auctions/join";

    return fetch(url, requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            return response.json();
        })
        .then(joinedAuction => {
            console.log('Joined auction:', joinedAuction);
            return joinedAuction;
        })
        .catch(error => {
            console.error('Error joining auction:', error);
            throw error;
        });
    
}

/*
    Function that places a bid on joined auction
    return value of type :
    {
        "tokens" : 5
    }
*/
function bid(auctionId, userId){
    const jsonData = {
        auctionId : auctionId,
        userId : userId
    };

    const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(jsonData)
      };

    const url = "http://localhost:8082/auctions/bid";

    return fetch(url, requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            return response.json();
        })
        .then(bidPlacedResponse => {
            console.log('Bid placed response:', bidPlacedResponse);
            return bidPlacedResponse;
        })
        .catch(error => {
            console.error('Error placing a bid:', error);
            throw error;
        });
}

//------------------------------------------------------------------------




function connect(){
    var socket = new SockJS("/our-websocket");
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function(frame){
        console.log('Connected: ' + frame);
        
        const match = /user-name:(\w+)/.exec(frame);
        myId = match[1];
        console.log("My id: " + myId);

        /*
            Initializing user info
        */
        getUserInfo(myId)
            .then(userInfo => {
                tokens = userInfo.tokens;
                username = userInfo.username;
                $("#username").html(username);
                $("#tokens").html(tokens);
            })
            .catch(error => {
                console.error('Error fetching user info:', error);
            });

        /*
            Initializing active auctions
        */
        getActiveAuctions()
            .then(activeAuctions => {
                handleAuctionsRefreshed(activeAuctions);
            })
            .catch(error =>{
                console.error('Error fetching active auctions:', error);
            });


        stompClient.subscribe('/topic/global-notification', function (message){
            handleAuctionsRefreshed(JSON.parse(message.body));
            
        });

        stompClient.subscribe('/user/topic/private-notification-token-refresh', function (message){
            handleTokensRefreshed(JSON.parse(message.body).tokens);
        });

        /*
            private Long auctionId;
            private Long currentBid;
            private Timestamp timestamp;
            private String player;
            private Long currentWinnerId;
        */
        stompClient.subscribe('/user/topic/private-notification-bid-placed', function (message){
            handleBidPlaced(JSON.parse(message.body));
        });
        /*
            private Long auctionId;
            private Long winnerId;
            private String player;
            private Long winningPrice;
        */
        stompClient.subscribe('/user/topic/private-notification-auction-finished', function (message){
            handleAuctionFinished(JSON.parse(message.body));
        });

        /*
            [
                {auctionId: 1},
                {auctionId: 2}
            ]
        */
        stompClient.subscribe('/topic/global-notification-tokens-back', function (message){
            handleTokensBackEvent(JSON.parse(message.body));
        });

    });
}

function handleTokensBackEvent(tokensBackEvent){
    tokensBackEvent.forEach(function(auction){
        $("#auction-joined-" + auction.auctionId).append($("<td>").append(generateTokensBackHtml()));
        $("#auction-active-" + auction.auctionId).append($("<td>").append(generateTokensBackHtml()));
    });
}

/*
    Function that handles auctionFinishedEvent
*/
function handleAuctionFinished(auctionFinishedEvent){
    $("#auction-joined-" + auctionFinishedEvent.auctionId).remove();
    if(auctionFinishedEvent.winnerId == myId){
        var row = $("<tr id='auction-won-" + auctionFinishedEvent.auctionId + "'>");
        row.append("<td>" + auctionFinishedEvent.auctionId + "</td>");
        
    
        var playerCell = $("<td>");
        playerCell.append(generatePlayerHtml(auctionFinishedEvent.player));
        row.append(playerCell);

        row.append("<td>" + auctionFinishedEvent.winningPrice+ "</td>");
        
        if(auctionFinishedEvent.tokensBack == true){
            row.append($("<td>").append(generateWinningTokensBackHtml(auctionFinishedEvent.tokensBackValue)));
            
            tokens = tokens + auctionFinishedEvent.tokensBackValue;
            $("#tokens").html(tokens);
        }
        

        row.css("background-color", "#90EE90");
        $("#won-auctions-table").prepend(row);
    }
}



/*
    Function that handles bid placed event
*/
function handleBidPlaced(auction){
    $("#auction-joined-" + auction.auctionId).remove();
    var row = $("<tr id='auction-joined-" + auction.auctionId + "'>");

    var dateObject = new Date(auction.timestamp);
    var numericTimeStamp = dateObject.getTime();
    var timeLeft = Math.ceil((numericTimeStamp - Date.now()) / 1000);

    row.append("<td>" + auction.auctionId + "</td>");
    
    var playerCell = $("<td>");
    playerCell.append(generatePlayerHtml(auction.player));
    row.append(playerCell);


    row.append("<td>" + auction.currentBid + "</td>");
    row.append("<td id='auction-joined-" + auction.auctionId + "-time' class='time' >" + timeLeft + "</td>");

    var button = $("<button>")
    .attr("id", "auction-" + auction.auctionId + "-bid")
    .addClass("btn btn-light")
    .text("Bid")
    .click(function() {
        handleBidClick(auction.auctionId);
    });


    row.append($("<td>").append(button));

    
    if(auction.tokensBack == true){
        row.append($("<td>").append(generateTokensBackHtml()));
    }

    if (auction.currentWinnerId == myId) {
        row.css("background-color", "#90EE90");
    }

    $("#joined-auctions-table").prepend(row);

}

/*
    Function that handles tokens refreshed event
*/
function handleTokensRefreshed(newTokens){
    
    tokens = newTokens;
    $("#tokens").html(newTokens);

}

/*
    Function that handles click on joinAuction auction button
    
*/
function handleJoinAuctionClick(auctionId){
    joinAuction(auctionId, myId)
        .then(joinedAuction => {
            var row = $("<tr id='auction-joined-" + joinedAuction.auctionId + "'>");

            joinedAuctions.push(joinedAuction);

            var dateObject = new Date(joinedAuction.timestamp);
            var numericTimeStamp = dateObject.getTime();
            var timeLeft = Math.ceil((numericTimeStamp - Date.now()) / 1000);

            row.append("<td>" + joinedAuction.auctionId + "</td>");
           
            var playerCell = $("<td>");
            playerCell.append(generatePlayerHtml(joinedAuction.player));
            row.append(playerCell);


            row.append("<td>" + joinedAuction.currentBid + "</td>");
            row.append("<td id='auction-joined-" + joinedAuction.auctionId + "-time' class='time' >" + timeLeft + "</td>");
            
            var button = $("<button>")
            .attr("id", "auction-" + joinedAuction.auctionId + "-bid")
            .addClass("btn btn-light")
            .text("Bid")
            .click(function() {
                handleBidClick(joinedAuction.auctionId);
            });



            row.append($("<td>").append(button));

            
            if(joinedAuction.tokensBack == true){
                row.append($("<td>").append(generateTokensBackHtml()));
            }
            
            $("#joined-auctions-table").append(row);
            
        })
        .catch(error => {
            console.error('Error joinin auction:', error);
        });
}

function handleBidClick(auctionId){
    bid(auctionId, myId)
        .then(bidPlacedResponse => {
            tokens = bidPlacedResponse.tokens;
            $("#tokens").html(bidPlacedResponse.tokens);
        })
        .catch(error => {
            console.error("Error bidding on auction: ", error);
        });
}


function handleAuctionsRefreshed(auctions){
    activeAuctionIds = [];
    rows = $();
    auctions.forEach(function(auction){
        var row = $("<tr id='auction-active-" + auction.auctionId + "'>");

        activeAuctionIds.push(auction.auctionId);

        var dateObject = new Date(auction.timestamp);
        var numericTimeStamp = dateObject.getTime();
        var timeLeft = Math.ceil((numericTimeStamp - Date.now()) / 1000);

        row.append("<td>" + auction.auctionId + "</td>");
        var playerCell = $("<td>");
        playerCell.append(generatePlayerHtml(auction.player));
        row.append(playerCell);

        row.append("<td id='auction-" + auction.auctionId + "-time' class='time' >" + timeLeft + "</td>");
        
        var button = $("<button>")
        .attr("id", "auction-" + auction.auctionId + "-join")
        .addClass("btn btn-light")
        .text("Join Auction")
        .click(function() {
            handleJoinAuctionClick(auction.auctionId);
        });


        row.append($("<td>").append(button));

        //dodato
        if(auction.tokensBack == true){
            row.append($("<td>").append(generateTokensBackHtml()));
        }

        row.addClass("align-middle");
        
        rows = rows.add(row);

    });

    $("#active-auctions-table").html(rows);
}


/*
    This function updates timers every second on each auction that is displayed on the screen, showing the remaining time to the user.
*/
function updateTimers(){
    

    $('.time').each(function(){
        var currentValue = parseInt($(this).text());
        if (!isNaN(currentValue) && currentValue > 0) {
            $(this).text(currentValue - 1);
            if (currentValue -1 < 5) {
                $(this).css('color', 'red');
            }
        }
    });

}

function generatePlayerHtml(player){
    var html = `
    <div style="height: 100%; border: 1px solid #000; border-radius: 5px; background-color: #87CEEB; padding: 10px;">
        <strong>Name:</strong> ${player.name}<br>
        <strong>Age:</strong> ${player.age}<br>
        <strong>Quality:</strong> ${player.quality}<br>
        <strong>Weight:</strong> ${player.weight}<br>
        <strong>Height:</strong> ${player.height}<br>
        <strong>Foot:</strong> ${player.foot}<br>
        <strong>Nationality:</strong> ${player.nationality}<br>
        <strong>Positions:</strong> ${player.playingPositions.map(position => position.name).join(", ")}
    </div>
`;


    return html;
}

function generateTokensBackHtml(){
    var html = `
    <div style="color: red; background-color: #FFFF00;">
        TOKENS BACK ON THIS AUCTION!
    </div>
`;
    return html;
}

function generateWinningTokensBackHtml(tokensBack){
    var html = `
    <div style="color: red; background-color: #FFFF00;">
        ${tokensBack} Tokens back!
    </div>
`;
    return html;
}

setInterval(updateTimers, 1000);
