package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;

import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.UserInfoResponse;

public interface UserService {

    UserInfoResponse getUser(Long userId);

}
