package com.nordeus.jobfair.auctionservice.auctionservice.domain.event;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Bid;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class BidPlacedEvent {

    private Auction auction;

}
