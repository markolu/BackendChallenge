package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;

import com.github.javafaker.Faker;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Position;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.PositionRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Random;

@Service
@AllArgsConstructor
public class RandomPlayerGenerator implements PlayerGenerator{


    private final Faker faker;
    private final PositionRepository positionRepository;
    @Override
    public Player generatePlayer() {
        Long positionId = (long)faker.number().numberBetween(1,12);
        Position position = positionRepository.findById(positionId).get();
        Player randomPlayer =  Player.builder()
                .name(faker.name().fullName())
                .quality(faker.number().numberBetween(1,5))
                .age(faker.number().numberBetween(18,40))
                .height(faker.number().numberBetween(170,200))
                .weight(faker.number().numberBetween(60,110))
                .nationality(faker.country().name())
                .foot(faker.random().nextBoolean() ? "right" : "left")
                .playingPositions(new HashSet<>())
                .build();
        randomPlayer.getPlayingPositions().add(position);
        position.getPlayers().add(randomPlayer);
        return randomPlayer;

    }



}
