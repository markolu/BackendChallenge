package com.nordeus.jobfair.auctionservice.auctionservice.domain.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.Set;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "players")
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private int age;

    private int quality;

    private int weight;

    private int height;

    private String foot;

    private String nationality;

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH})
    @JoinTable(
            name = "player_position",
            joinColumns = @JoinColumn(name="player_id"),
            inverseJoinColumns = @JoinColumn(name="position_id")
    )
    @JsonManagedReference
    private Set<Position> playingPositions;



    @OneToOne(mappedBy = "player", cascade = CascadeType.ALL)
    @JsonBackReference
    private Auction auction;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    @JsonBackReference
    private User owner;

    @Override
    public String toString(){
        return "[ id= " + id + " name= " + name + " positions= " + playingPositions + " ]";
    }

}
