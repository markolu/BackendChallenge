package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;


import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;

@Service
@AllArgsConstructor
@Slf4j
public class PeriodicAuctionMaintenance {

    private final AuctionService auctionService;


    @Order(1)
    @Scheduled(initialDelay = 1000, fixedRate = 1000)
    public void performOneSecondScheduledMaintenance(){
        auctionService.checkForTokensBack();
        auctionService.updateAuctionStatus();
    }


    @Order(2)
    @Scheduled(initialDelay = 0, fixedRate = 60000)
    public void performOneMinuteScheduledMaintenance(){
        auctionService.generateNewAuctions();
    }


}
