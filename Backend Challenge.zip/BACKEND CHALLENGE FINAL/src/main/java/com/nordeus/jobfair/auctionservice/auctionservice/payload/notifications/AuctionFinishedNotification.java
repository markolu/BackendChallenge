package com.nordeus.jobfair.auctionservice.auctionservice.payload.notifications;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AuctionFinishedNotification {

    private Long auctionId;
    private Long winnerId;
    private Player player;
    private Long winningPrice;
    private boolean tokensBack;
    private int tokensBackValue;

}
