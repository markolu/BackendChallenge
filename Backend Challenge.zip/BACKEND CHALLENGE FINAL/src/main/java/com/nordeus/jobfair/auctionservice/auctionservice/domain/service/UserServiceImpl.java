package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.User;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.PlayerRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.UserRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception.UserNotPresentException;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.UserInfoResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService{

    private final UserRepository userRepository;


    @Override
    @Transactional
    public UserInfoResponse getUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotPresentException(userId));

        return UserInfoResponse.builder()
                .tokens(user.getTokens())
                .username(user.getUsername())
                .build();

    }




}
