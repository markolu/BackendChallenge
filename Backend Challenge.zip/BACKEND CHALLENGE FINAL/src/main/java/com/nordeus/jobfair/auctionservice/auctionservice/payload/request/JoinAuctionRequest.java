package com.nordeus.jobfair.auctionservice.auctionservice.payload.request;

import lombok.Data;

@Data
public class JoinAuctionRequest {
    private Long auctionId;
    private Long userId;
}
