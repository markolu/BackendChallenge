package com.nordeus.jobfair.auctionservice.auctionservice.domain.repository;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;

public interface AuctionRepository extends JpaRepository<Auction, Long> {

    @Query(value = "SELECT * FROM AUCTIONS a WHERE a.status = 'ACTIVE'",
    nativeQuery = true)
    Collection<Auction> findActiveAuctions();

    @Query("SELECT a FROM Auction a WHERE a.tokensBack = true")
    Collection<Auction> findAuctionsWithTokensBackSet();

    @Query("SELECT a FROM Auction a WHERE a.joiningTime <= :targetTime AND a.status <> 'INACTIVE'")
    Collection<Auction> findAuctionsEndingBefore(@Param("targetTime") Timestamp targetTime);

    @Query("SELECT a FROM Auction a WHERE a.joiningTime <= :targetTime AND a.biddingTime <= :targetTime AND a.status != 'INACTIVE'")
    Collection<Auction> findAuctionsToBeEnded(@Param("targetTime") Timestamp targetTime);

    @Query("SELECT a FROM Auction a WHERE a.joiningTime <= :targetTime AND a.biddingTime > :targetTime AND a.status != 'INACTIVE'")
    Collection<Auction> findAuctionsToForbidJoining(@Param("targetTime") Timestamp targetTime);


    @Modifying
    @Query("UPDATE Auction a SET a.tokensBack = true WHERE a.status != 'INACTIVE'")
    void setTokensBackForOngoingAuctions();





}
