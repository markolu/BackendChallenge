package com.nordeus.jobfair.auctionservice.auctionservice.payload.request;


import lombok.Data;

@Data
public class BidOnAuctionRequest {
    private Long auctionId;
    private Long userId;
}
