package com.nordeus.jobfair.auctionservice.auctionservice.payload.notifications;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TokenRefreshNotification {
    private Long tokens;
}
