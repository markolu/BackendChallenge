package com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.text.MessageFormat;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class AuctionNotFoundException extends RuntimeException{

    public AuctionNotFoundException(final Long id){
        super(MessageFormat.format("Error: Auction with id {0} does not exsist!", Long.toString(id)));
    }

}
