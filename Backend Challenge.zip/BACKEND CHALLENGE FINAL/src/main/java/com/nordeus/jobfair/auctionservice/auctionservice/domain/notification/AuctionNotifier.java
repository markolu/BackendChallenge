package com.nordeus.jobfair.auctionservice.auctionservice.domain.notification;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Bid;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.User;

import java.util.Collection;

public interface AuctionNotifier {

    void auctionFinished(Auction auction);

    void bidPlaced(Auction auction);

    void activeAuctionsRefreshed(Collection<Auction> activeAuctions);

    void userTokenRefreshed(User user);

    void tokensBackNotification(Collection<Auction> auctionsWithTokensBack);

}
