package com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.text.MessageFormat;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class AuctionNoLongerActiveException extends RuntimeException {

    public AuctionNoLongerActiveException(final Long id){
        super(MessageFormat.format("Auction with id {0} is no longer active", Long.toString(id)));
    }

}
