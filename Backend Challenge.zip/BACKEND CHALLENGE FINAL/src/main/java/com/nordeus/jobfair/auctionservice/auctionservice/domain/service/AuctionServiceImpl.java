package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.event.*;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Bid;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.User;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.AuctionRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.BidRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.PlayerRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.UserRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception.*;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.notifications.ActiveAuctionNotification;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.AuctionInfoResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.BidPlacedResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.JoinAuctionResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.MessageResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Hibernate;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

@Service
@Slf4j
public class AuctionServiceImpl implements AuctionService {

    private final AuctionRepository auctionRepository;
    private final UserRepository userRepository;

    private final BidRepository bidRepository;

    private final AuctionGenerator auctionGenerator;

    private final PlayerRepository playerRepository;

    private final ApplicationEventPublisher applicationEventPublisher;

    private int tokensBackTimePassed;
    private int tokensBackDelay;


    public AuctionServiceImpl(
            AuctionRepository auctionRepository,
            UserRepository userRepository,
            BidRepository bidRepository,
            AuctionGenerator auctionGenerator,
            PlayerRepository playerRepository,
            ApplicationEventPublisher applicationEventPublisher
    ) {
        this.auctionRepository = auctionRepository;
        this.userRepository = userRepository;
        this.bidRepository = bidRepository;
        this.auctionGenerator = auctionGenerator;
        this.playerRepository = playerRepository;
        this.applicationEventPublisher = applicationEventPublisher;
        this.tokensBackTimePassed = 0;
        this.tokensBackDelay = 0;
    }



    @Override
    @Transactional
    public Collection<AuctionInfoResponse> getAllActive() {

        Collection<Auction> activeAuctions =  auctionRepository.findActiveAuctions();
        List<AuctionInfoResponse> list = new LinkedList<>();
        for(Auction a: activeAuctions){
            list.add(
                    AuctionInfoResponse.builder()
                            .auctionId(a.getId())
                            .player(a.getPlayer())
                            .timestamp(a.getJoiningTime())
                            .tokensBack(a.isTokensBack())
                            .build()
            );
        }

        return list;
    }

    @Override
    public Auction getAuction(Long auctionId) {
        return null;
    }

    @Override
    @Transactional
    public JoinAuctionResponse join(Long auctionId, Long userId) {

        Auction auction = auctionRepository.findById(auctionId)
                .orElseThrow(() -> new AuctionNotFoundException(auctionId));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotPresentException(userId));

        if (auction.getJoinedUsers().contains(user)) throw new UserAlreadyInAuctionException(userId);

        if (!"ACTIVE".equals(auction.getStatus())) throw new AuctionNoLongerActiveException(auctionId);

        auction.getJoinedUsers().add(user);
        user.getJoinedAuctions().add(auction);
        auctionRepository.save(auction);


        return JoinAuctionResponse.builder()
                .auctionId(auction.getId())
                .player(auction.getPlayer())
                .timestamp(auction.getBiddingTime())
                .currentBid(auction.getLatestBid() != null ? auction.getLatestBid().getAmount() : (long)0)
                .currentWinnerId(auction.getLatestBid() != null ? auction.getLatestBid().getUser().getId() : null)
                .tokensBack(auction.isTokensBack())
                .build();
    }


    @Override
    @Transactional
    public BidPlacedResponse bid(Long auctionId, Long userId) {
        Auction auction = auctionRepository.findById(auctionId)
                .orElseThrow(() -> new AuctionNotFoundException(auctionId));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotPresentException(userId));

        Bid latestBid = auction.getLatestBid();

        if ("INACTIVE".equals(auction.getStatus())) throw new AuctionNoLongerActiveException(auctionId);

        if (!auction.getJoinedUsers().contains(user)) throw new UserNotJoinedAuctionException(userId);

        int newAmount = (latestBid == null ? 1 : latestBid.getAmount() + 1);


        //User doesn't have enough tokens if he is previos bidder and has less than 1 token or if he is not previos bidder and doesn't have at least newAmount tokens
        if((latestBid != null && latestBid.getUser() == user && user.getTokens() < 1)
                || ((latestBid == null || latestBid.getUser() != user) && user.getTokens() < newAmount)
        ) throw new UserDoesntHaveEnoughTokensException(userId);




        user.setTokens(user.getTokens() - newAmount);
        User savedCurrentBidder = userRepository.save(user);

        if(latestBid != null){
            User previousBidder = latestBid.getUser();
            previousBidder.setTokens(previousBidder.getTokens() + latestBid.getAmount());
            User savedPreviousBidder = userRepository.save(previousBidder);


            applicationEventPublisher.publishEvent(new UserTokenRefreshEvent(savedPreviousBidder));
        }

        Bid newBid = Bid.builder()
                .user(user)
                .auction(auction)
                .amount(newAmount)
                .build();

        Bid newLatestBid = bidRepository.save(newBid);

        auction.setLatestBid(newLatestBid);

        if(auction.getBiddingTime().getTime() < new Timestamp(System.currentTimeMillis()).getTime() + 5000){
            auction.setBiddingTime(new Timestamp(System.currentTimeMillis() + 5000));
            log.info("Prolonged bidding time on auction with id: {}", auction.getId());
        }

        Auction updatedAuction = auctionRepository.save(auction);

        applicationEventPublisher.publishEvent(new BidPlacedEvent(updatedAuction));

        return BidPlacedResponse.builder().tokens(savedCurrentBidder.getTokens()).build();

    }



    @Override
    @Transactional
    public void updateAuctionStatus() {
        Timestamp targetTime = new Timestamp(System.currentTimeMillis());
        Collection<Auction> auctionsToBeSetToInactive = auctionRepository.findAuctionsToBeEnded(targetTime);
        Collection<Auction> auctionsToBeSetToClosing = auctionRepository.findAuctionsToForbidJoining(targetTime);

        //set auction status to closing
        for(Auction a: auctionsToBeSetToClosing){
            a.setStatus("CLOSING");
            auctionRepository.save(a);
        }

        for(Auction auction: auctionsToBeSetToInactive){
            auction.setStatus("INACTIVE");
            auction = auctionRepository.save(auction);

            //If there is no bid, notify auction finished for joined users, remove player->remove auction->remove user_auction
            if(auction.getLatestBid() == null){
                //dodato
                applicationEventPublisher.publishEvent(new AuctionFinishedEvent(auction));
                playerRepository.delete(auction.getPlayer());
            }
            else{
                //Make a winning user owner of auctions player
                User winner = auction.getLatestBid().getUser();
                Player wonPlayer = auction.getPlayer();
                wonPlayer.setOwner(winner);
                winner.getOwnedPlayers().add(wonPlayer);

                //Return player tokens if tokensBack is active on auction
                if(auction.isTokensBack()){
                    int playerPrice = auction.getLatestBid().getAmount();
                    double randomPercentage = (Math.random() * (0.5-0.2)) + 0.2;
                    int tokensBackValue = (int)(playerPrice * randomPercentage);
                    auction.setTokensBackValue(tokensBackValue);
                    winner.setTokens(winner.getTokens() + tokensBackValue);
                }

                //save the winner
                userRepository.save(winner);

                //notify that auction has finished
                applicationEventPublisher.publishEvent(new AuctionFinishedEvent(auction));

                //remove all users that participate in finished auction
                auction.getJoinedUsers().clear();
                auctionRepository.save(auction);
            }
        }
    }

    @Override
    @Transactional
    public void checkForTokensBack(){
        if(tokensBackTimePassed == 180) tokensBackTimePassed = 0;
        if(tokensBackTimePassed == 0){
            tokensBackDelay = new Random().nextInt(180);
            log.info("Tokens back in: {} seconds", tokensBackDelay);
        }
        if(tokensBackTimePassed == tokensBackDelay){
            auctionRepository.setTokensBackForOngoingAuctions();
            Collection<Auction> auctionsWithTokensBack = auctionRepository.findAuctionsWithTokensBackSet();
            applicationEventPublisher.publishEvent(new TokensBackEvent(auctionsWithTokensBack));
        }
        tokensBackTimePassed++;
    }

    @Override
    @Transactional
    public void generateNewAuctions() {
        Collection<Auction> auctions = new LinkedList<>();

        for(int i = 0; i < 10; i++){
            auctions.add(auctionGenerator.generateAuction());
        }

        Collection<Auction> newAuctions = auctionRepository.saveAll(auctions);


        applicationEventPublisher.publishEvent(new AuctionsRefreshedEvent(newAuctions));
    }




}
