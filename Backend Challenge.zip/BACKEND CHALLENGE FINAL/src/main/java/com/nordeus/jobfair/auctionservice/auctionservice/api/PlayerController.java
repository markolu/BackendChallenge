package com.nordeus.jobfair.auctionservice.auctionservice.api;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.PlayerService;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception.UserNotPresentException;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;

@AllArgsConstructor
@RestController
@RequestMapping(path = "/players")
public class PlayerController {

    private final PlayerService playerService;

    @GetMapping("/byOwner")
    public ResponseEntity<Collection<Player>> getPlayersByOwner(@RequestParam Long ownerId){

        try {
            Collection<Player> players = playerService.getPlayersOwnedByUser(ownerId);

            return ResponseEntity.ok().body(players);

        } catch (UserNotPresentException e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }

    }

}
