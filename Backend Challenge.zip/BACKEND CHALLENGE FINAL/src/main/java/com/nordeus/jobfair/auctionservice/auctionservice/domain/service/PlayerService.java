package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;

import java.util.Collection;

public interface PlayerService {

    Collection<Player> getPlayersOwnedByUser(Long userId);

}
