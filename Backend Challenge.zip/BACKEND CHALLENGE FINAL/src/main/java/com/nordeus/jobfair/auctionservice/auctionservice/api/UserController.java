package com.nordeus.jobfair.auctionservice.auctionservice.api;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.UserService;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception.UserNotPresentException;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.UserInfoResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@AllArgsConstructor
@RestController
@RequestMapping(path = "/users")
public class UserController {

    private final UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<UserInfoResponse> getUser(@PathVariable("id") Long id){

        try{

            UserInfoResponse response = userService.getUser(id);
            return ResponseEntity.ok().body(response);

        } catch (UserNotPresentException e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }

    }

}
