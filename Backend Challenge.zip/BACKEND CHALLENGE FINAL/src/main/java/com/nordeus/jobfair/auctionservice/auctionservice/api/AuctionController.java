package com.nordeus.jobfair.auctionservice.auctionservice.api;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.BidRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.PlayerRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.AuctionService;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception.*;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.request.BidOnAuctionRequest;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.request.JoinAuctionRequest;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.AuctionInfoResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.BidPlacedResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.JoinAuctionResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.MessageResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;

@AllArgsConstructor
@RestController
@RequestMapping(path = "/auctions")
public class AuctionController {

    private final AuctionService auctionService;

    @GetMapping("/active")
    public ResponseEntity<Collection<AuctionInfoResponse>> getAllActive() {

        return ResponseEntity.ok().body(auctionService.getAllActive());

    }

    @PostMapping("/join")
    public ResponseEntity<JoinAuctionResponse> joinAuction(@RequestBody JoinAuctionRequest joinAuctionRequest){
        try{

            JoinAuctionResponse response = auctionService.join(joinAuctionRequest.getAuctionId(), joinAuctionRequest.getUserId());
            return ResponseEntity.ok().body(response);

        } catch(UserNotPresentException | AuctionNotFoundException e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        } catch(UserAlreadyInAuctionException | AuctionNoLongerActiveException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @PostMapping("/bid")
    public ResponseEntity<BidPlacedResponse> bidOnAuction(@RequestBody BidOnAuctionRequest bidOnAuctionRequest){
        try{

            BidPlacedResponse response = auctionService.bid(bidOnAuctionRequest.getAuctionId(), bidOnAuctionRequest.getUserId());
            return ResponseEntity.ok().body(response);

        } catch (UserNotPresentException | AuctionNotFoundException e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        } catch (UserNotJoinedAuctionException | UserDoesntHaveEnoughTokensException | AuctionNoLongerActiveException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }






}
