package com.nordeus.jobfair.auctionservice.auctionservice.payload.response;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;

@Data
@Builder
public class JoinAuctionResponse {
    private Long auctionId;
    private Long currentBid;
    private Timestamp timestamp;
    private Player player;
    private Long currentWinnerId;
    private boolean tokensBack;
}
