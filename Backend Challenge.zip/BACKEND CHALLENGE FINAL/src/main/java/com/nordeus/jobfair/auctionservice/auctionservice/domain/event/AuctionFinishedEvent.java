package com.nordeus.jobfair.auctionservice.auctionservice.domain.event;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuctionFinishedEvent {

    Auction auction;

}
