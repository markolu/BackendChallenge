package com.nordeus.jobfair.auctionservice.auctionservice.domain.event.handler;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.event.AuctionFinishedEvent;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.event.UserTokenRefreshEvent;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.notification.AuctionNotifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class SendUserTokenRefreshHandler {

    @Autowired
    private AuctionNotifier auctionNotifier;

    @EventListener
    public void handleUserTokeNRefresh(UserTokenRefreshEvent e){
        auctionNotifier.userTokenRefreshed(e.getUser());
    }

}
