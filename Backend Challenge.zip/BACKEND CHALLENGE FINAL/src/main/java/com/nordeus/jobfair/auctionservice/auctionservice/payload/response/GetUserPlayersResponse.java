package com.nordeus.jobfair.auctionservice.auctionservice.payload.response;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class GetUserPlayersResponse {

    List<Player> players;

}
