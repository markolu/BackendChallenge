package com.nordeus.jobfair.auctionservice.auctionservice.payload.notifications;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class TokensBackNotification {

    private Long auctionId;

}
