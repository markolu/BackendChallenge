package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.User;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.PlayerRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.repository.UserRepository;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception.UserNotPresentException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@AllArgsConstructor
@Service
public class PlayerServiceImpl implements PlayerService {

    private final PlayerRepository playerRepository;

    private final UserRepository userRepository;

    @Override
    @Transactional
    public Collection<Player> getPlayersOwnedByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotPresentException(userId));

        return playerRepository.findAllByOwner(user);

    }
}
