package com.nordeus.jobfair.auctionservice.auctionservice.domain.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.DialectOverride;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.sql.Timestamp;
import java.util.Set;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "auctions")
public class Auction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="player_id", referencedColumnName = "id")
    @JsonManagedReference
    private Player player;


    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name="latest_bid_id", referencedColumnName = "id")
    @JsonManagedReference
    private Bid latestBid;

    private String status;

    private Timestamp joiningTime;
    private Timestamp biddingTime;

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH})
    @JoinTable(
            name = "user_auction",
            joinColumns = @JoinColumn(name="auction_id"),
            inverseJoinColumns = @JoinColumn(name="user_id")
    )
    @JsonManagedReference
    private Set<User> joinedUsers;

    private boolean tokensBack;

    private int tokensBackValue;




    @Override
    public String toString(){
        return "[ id= " + id + " joining_time= " + joiningTime + " bidding_time= " + biddingTime + " ]" + "player: " + player;
    }

}
