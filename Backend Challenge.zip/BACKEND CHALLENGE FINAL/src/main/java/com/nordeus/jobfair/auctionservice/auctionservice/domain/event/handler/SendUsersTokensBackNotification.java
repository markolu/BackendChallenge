package com.nordeus.jobfair.auctionservice.auctionservice.domain.event.handler;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.event.AuctionsRefreshedEvent;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.event.TokensBackEvent;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.notification.AuctionNotifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class SendUsersTokensBackNotification {

    @Autowired
    private AuctionNotifier auctionNotifier;

    @EventListener
    public void handleTokensBackEvent(TokensBackEvent e){
        auctionNotifier.tokensBackNotification(e.getAuctions());
    }

}
