package com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.text.MessageFormat;

@ResponseStatus(code = HttpStatus.NOT_FOUND)
public class UserNotPresentException extends RuntimeException{


    public UserNotPresentException(final Long id){
        super(MessageFormat.format("Error: User with id {0} does not exsist!", Long.toString(id)));
    }


}
