package com.nordeus.jobfair.auctionservice.auctionservice.domain.notification;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.User;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.notifications.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

@Slf4j
@Service
@AllArgsConstructor
public class AuctionNotifierImplementation implements AuctionNotifier {

    private final SimpMessagingTemplate simpMessagingTemplate;

    @Override
    public void auctionFinished(Auction auction) {

        AuctionFinishedNotification notification = AuctionFinishedNotification
                .builder()
                .winningPrice(auction.getLatestBid() != null ? auction.getLatestBid().getAmount() : (long)0)
                .winnerId(auction.getLatestBid() != null ? auction.getLatestBid().getUser().getId() : null)
                .player(auction.getPlayer())
                .auctionId(auction.getId())
                .tokensBack(auction.isTokensBack())
                .tokensBackValue(auction.getTokensBackValue())
                .build();

        for(User user: auction.getJoinedUsers()){
            simpMessagingTemplate.convertAndSendToUser(user.getId().toString(), "/topic/private-notification-auction-finished", notification);
        }
        log.info("Auction finished: {}\n\t\tWinner: {}", auction, (auction.getLatestBid() != null ? auction.getLatestBid().getUser() : "Nema pobednika"));
    }

    @Override
    public void bidPlaced(Auction auction) {

        BidPlacedNotification notification = BidPlacedNotification
                .builder()
                .auctionId(auction.getId())
                .currentBid((long)auction.getLatestBid().getAmount())
                .player(auction.getPlayer())
                .timestamp(auction.getBiddingTime())
                .currentWinnerId(auction.getLatestBid().getUser().getId())
                .tokensBack(auction.isTokensBack())
                .build();

        for(User user: auction.getJoinedUsers()){
            simpMessagingTemplate.convertAndSendToUser(user.getId().toString(), "/topic/private-notification-bid-placed", notification);
        }

        log.info("Bid placed: {}.", auction.getLatestBid());
    }

    @Override
    public void activeAuctionsRefreshed(Collection<Auction> activeAuctions) {
        List<ActiveAuctionNotification> list = new LinkedList<>();
        for(Auction a: activeAuctions){
            list.add(
                    ActiveAuctionNotification.builder()
                            .auctionId(a.getId())
                            .player(a.getPlayer())
                            .timestamp(a.getJoiningTime())
                            .tokensBack(a.isTokensBack())
                            .build()
            );
        }

        simpMessagingTemplate.convertAndSend("/topic/global-notification", list);

        System.out.println("Active auctions refreshed: " + activeAuctions);
    }

    @Override
    public void userTokenRefreshed(User user) {

        TokenRefreshNotification notification = TokenRefreshNotification.builder().tokens(user.getTokens()).build();

        simpMessagingTemplate.convertAndSendToUser(user.getId().toString(), "/topic/private-notification-token-refresh", notification);
        log.info("Token refresh for user with id {} : {}", user.getId(), user.getTokens());
    }

    @Override
    public void tokensBackNotification(Collection<Auction> auctionsWithTokensBack) {
        List<TokensBackNotification> list = new LinkedList<>();
        for(Auction a: auctionsWithTokensBack){
            list.add(
                    TokensBackNotification.builder().auctionId(a.getId()).build()
            );
        }

        simpMessagingTemplate.convertAndSend("/topic/global-notification-tokens-back", list);

        log.info("Tokens back occured on auctions: {}", auctionsWithTokensBack );

    }
}
