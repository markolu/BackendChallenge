package com.nordeus.jobfair.auctionservice.auctionservice.domain.service.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.text.MessageFormat;

@ResponseStatus(code = HttpStatus.BAD_REQUEST)
public class UserAlreadyInAuctionException extends RuntimeException{


    public UserAlreadyInAuctionException(final Long id){
        super(MessageFormat.format("Error: User with id {0} is already in auction!", Long.toString(id)));
    }


}