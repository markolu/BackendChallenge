package com.nordeus.jobfair.auctionservice.auctionservice.domain.event;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class UserTokenRefreshEvent {

    User user;

}
