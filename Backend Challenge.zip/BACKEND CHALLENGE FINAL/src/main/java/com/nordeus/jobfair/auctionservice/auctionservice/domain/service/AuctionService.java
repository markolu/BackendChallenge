package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Bid;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.User;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.AuctionInfoResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.BidPlacedResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.JoinAuctionResponse;
import com.nordeus.jobfair.auctionservice.auctionservice.payload.response.MessageResponse;

import java.util.Collection;
import java.util.List;

public interface AuctionService {

    Collection<AuctionInfoResponse> getAllActive();

    Auction getAuction(Long auctionId);

    JoinAuctionResponse join(Long auctionId, Long userId);

    BidPlacedResponse bid(Long auctionId, Long userId);


    void generateNewAuctions();

    void updateAuctionStatus();

    void checkForTokensBack();


}
