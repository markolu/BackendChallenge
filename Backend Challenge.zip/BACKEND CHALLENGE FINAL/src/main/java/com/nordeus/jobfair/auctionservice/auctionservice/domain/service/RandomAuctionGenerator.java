package com.nordeus.jobfair.auctionservice.auctionservice.domain.service;

import com.github.javafaker.Faker;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;

@Service
@AllArgsConstructor
public class RandomAuctionGenerator implements AuctionGenerator {

    private final PlayerGenerator playerGenerator;

    @Override
    public Auction generateAuction() {
        Timestamp time = new Timestamp(System.currentTimeMillis() + 60000);
        return Auction.builder()
                .player(playerGenerator.generatePlayer())
                .status("ACTIVE")
                .joiningTime(time)
                .biddingTime(time)
                .tokensBack(false)
                .tokensBackValue(0)
                .build();
    }
}
