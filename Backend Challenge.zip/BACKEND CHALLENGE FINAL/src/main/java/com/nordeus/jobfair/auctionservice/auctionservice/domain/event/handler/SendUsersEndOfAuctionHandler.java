package com.nordeus.jobfair.auctionservice.auctionservice.domain.event.handler;

import com.nordeus.jobfair.auctionservice.auctionservice.domain.event.AuctionFinishedEvent;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.event.BidPlacedEvent;
import com.nordeus.jobfair.auctionservice.auctionservice.domain.notification.AuctionNotifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class SendUsersEndOfAuctionHandler {

    @Autowired
    private AuctionNotifier auctionNotifier;

    @EventListener
    public void handleAuctionFinished(AuctionFinishedEvent e){
        auctionNotifier.auctionFinished(e.getAuction());
    }

}
