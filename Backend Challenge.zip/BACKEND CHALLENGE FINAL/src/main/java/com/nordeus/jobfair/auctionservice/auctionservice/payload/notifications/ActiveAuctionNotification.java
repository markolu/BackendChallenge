package com.nordeus.jobfair.auctionservice.auctionservice.payload.notifications;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Player;
import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;

@Data
@Builder
public class ActiveAuctionNotification {
    private Long auctionId;
    private Player player;
    private Timestamp timestamp;
    private boolean tokensBack;
}
