package com.nordeus.jobfair.auctionservice.auctionservice.domain.event;


import com.nordeus.jobfair.auctionservice.auctionservice.domain.model.Auction;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Collection;

@AllArgsConstructor
@Data
public class AuctionsRefreshedEvent {

    private Collection<Auction> auctions;

}
